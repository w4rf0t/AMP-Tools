import json
import random
from time import sleep
while True:
    with open('status_of_function.json') as f:
        data = json.load(f)
        for i in data:
            i['status'] = random.randint(0,1)
            print(i['name'],i['status'])
    with open('status_of_function.json', 'w') as f:
        json.dump(data, f)
    sleep(1)