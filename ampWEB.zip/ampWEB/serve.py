import json
import os
import random
import datetime
from time import sleep
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/status')
def status():
    return render_template('status.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')



@app.route('/status', methods=['POST'])
def handle_input_form():
    target = request.form.get('domains')
    startTime = datetime.datetime.now()
    # process the data
    # os.system('python3 AMP-Tools/main.py ' + target)
    
    return render_template('status.html',startTime=startTime)

@app.route('/status/update',methods=['POST'])
def get_status():
    target = request.form.get('domains')
    with open(f'AMP-Tools/Result/{target}/status_of_function.json') as f:
        data = json.load(f)
    return jsonify(data)

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

if __name__ == '__main__':
    app.run(debug=True)